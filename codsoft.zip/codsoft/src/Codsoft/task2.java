package Codsoft;
import java.util.Scanner;
public class task2 {
	 public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 System.out.println("how many number of subjects");
		 int subs=sc.nextInt();
		 int[] marks=new int[subs];
		 int totmark=0;
		 for(int i=0;i<subs;i++) {
			 System.out.println("enter marks for sub"+(i+1)+"for 100");
			 
			marks[i]=sc.nextInt();
			totmark+=marks[i];
		 }
		 double avg=totmark/subs;
		 String grade;
		 if(avg>90&&avg<70) {
			 grade="A";
		 }
		 else if(avg>80&&avg<70) {
			 grade="B";
		 }
		 else if(avg>=60) {
			 grade="C";
	 }
		 else {
			 grade="F";
		 }
		 System.out.println("\n results");
		 System.out.println("totalmarks"+totmark);
		 System.out.println("averagemarks"+avg);
		 System.out.println("grade"+grade);
		 }
}
