package Codsoft;
import java.util.Random;
public class Rage {
    public static int gr() {
        Random random = new Random();
        return random.nextInt(100)+1;
    }
public static void main(String[]args)
{
        int randomn = gr();
        System.out.println("Random num between 1 to 100 is" + randomn);
}
}