package Codsoft;
import java.util.Random;
import java.util.*;
public class guess{
	public static int gr()
{
	Random random=new Random();
	return random.nextInt(100)+1;
}
public static void main(String[]args)
{
        int randomn = gr();
        Scanner sc=new Scanner(System.in);
        System.out.println("guess the num 1-100");
        int g=sc.nextInt();
        System.out.println("guessed"+g);
        System.out.println("generated num is" + randomn);
}
}
