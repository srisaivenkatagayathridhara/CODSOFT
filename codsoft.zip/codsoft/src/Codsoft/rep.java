package Codsoft;
import java.util.Random;
import java.util.Scanner;
public class rep {
	public static int gr()
	{
		Random random=new Random();
		return random.nextInt(100)+1;
	}
	public static void main(String[]args) {
	    int randomn = gr();
	    Scanner sc=new Scanner(System.in);
	    int G=0;
	    while(G!=randomn) {
	    	System.out.println("guess the num 1-100");
	        G=sc.nextInt();
	        if(G==randomn) {
	    		System.out.println("correct");
	        }
	    		else if(G<randomn) {
	    			System.out.println("too low");
	    		}
	    		else {
	    			System.out.println("too high");
	    		}
	    		System.out.println("actual num"+randomn);
	    }
}
}
