package Codsoft;

import java.util.Random;
import java.util.Scanner;

public class add1 {
    static int attem = 3;
    Scanner sc = new Scanner(System.in);
    Random random = new Random();
    int totscore = 0;
    int onceagain;

    public void startGame() {
        do {
            int randomn = random.nextInt(100) + 1;
            System.out.println("\nYou have " + attem + " attempts to guess the number.");
            for (int i = 0; i < attem; i++) {
                System.out.println("Guess the number (1-100):");
                int G = sc.nextInt();

                if (G == randomn) {
                    System.out.println("Correct guess in " + (i + 1) + " attempt(s).");
                    totscore += attem - i;
                    break;
                } else if (G < randomn) {
                    System.out.println("Too low");
                } else {
                    System.out.println("Too high");
                }

                if (i == attem - 1) {
                    System.out.println("Attempts over! The correct number was " + randomn);
                }
            }

            System.out.println("Once again? Type 1 for Yes, 0 for No:");
            onceagain = sc.nextInt();
        } while (onceagain == 1); 

        System.out.println("Game over. Total score is: " + totscore);
    }

    public static void main(String[] args) {
        add1 game = new add1();
        game.startGame();
    }
}
