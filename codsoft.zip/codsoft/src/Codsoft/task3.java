package Codsoft;

import java.util.Scanner;

class BankAccount {
    private double balance = 100;

    String deposit(double amount) {
        balance += amount;
        return "Deposited: " + amount;
    }

    String withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            return "Withdrawn: " + amount;
        } else {
            return "Insufficient balance";
        }
    }

    String checkBalance() {
        return "Balance: " + balance;
    }
}

class ATM {
    private BankAccount account = new BankAccount();

    String handleOption(int option, double amount) {
        switch (option) {
            case 1:
                return account.withdraw(amount);
            case 2:
                return account.deposit(amount);
            case 3:
                return account.checkBalance();
            default:
                return "Invalid option";
        }
    }
}

public class task3 { 
    public static void main(String[] args) {
        ATM atm = new ATM();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("\n1. Withdraw 2. Deposit 3. Check Balance 4. Exit: ");
            int option = scanner.nextInt();

            if (option == 4) break;

            double amount = 0;
            if (option == 1 || option == 2) {
                System.out.print("Enter amount: ");
                amount = scanner.nextDouble();
            }

            System.out.println(atm.handleOption(option, amount));
        }

        scanner.close();
        System.out.println("Thank you for using the ATM.");
    }
}
